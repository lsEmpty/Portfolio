﻿using Primerito;
using System.Runtime.InteropServices;

namespace Talleres
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Empleado> listEmpleado = new List<Empleado>();
            List<Administrador> listAdministrador = new List<Administrador>();
            bool flag = true;
            while (flag)
            {
                Console.Clear();
                Console.WriteLine("Programita para crear empleados & administradores");
                Console.WriteLine("1. Para crear Empleado");
                Console.WriteLine("2. Para crear Administrador");
                Console.WriteLine("Escribe cualquier otro numero para salir y mostrar los empleados & administradores");
                int opc = int.Parse(Console.ReadLine());
                switch (opc)
                {
                    case 1:
                        Empleado empleado = new Empleado();
                        Console.WriteLine("Crear Empleado");
                        Console.WriteLine("Escribe su identificacion");
                        empleado.id = Console.ReadLine();
                        Console.WriteLine("Escribe el nombre");
                        empleado.name = Console.ReadLine();
                        Console.WriteLine("Escribe su direccion");
                        empleado.address = Console.ReadLine();
                        Console.WriteLine("Escribe el telefono");
                        empleado.telephone = Console.ReadLine();
                        Console.WriteLine("Escribe su nacionalidad");
                        empleado.nationality = Console.ReadLine();

                        listEmpleado.Add(empleado);
                        Console.WriteLine("Usuario registrado");
                        Console.ReadKey();

                        break;
                    case 2:
                        Administrador admin = new Administrador();
                        Console.WriteLine("Crear Administrador");
                        Console.WriteLine("Escribe su identificacion");
                        admin.id = Console.ReadLine();
                        Console.WriteLine("Escribe el nombre");
                        admin.name = Console.ReadLine();
                        Console.WriteLine("Escribe su direccion");
                        admin.address = Console.ReadLine();
                        Console.WriteLine("Escribe el telefono");
                        admin.telephone = Console.ReadLine();
                        Console.WriteLine("Escribe su nacionalidad");
                        admin.nationality = Console.ReadLine();

                        listAdministrador.Add(admin);
                        Console.WriteLine("Usuario registrado");
                        Console.ReadKey();
                        break;
                    default:
                        flag = false;
                        break;

                }
            }
            Console.Clear();
            if (listEmpleado.Count != 0)
            {
                Console.WriteLine("Lista de empleados creados: ");
                foreach (Empleado empleado in listEmpleado)
                {
                    Console.WriteLine("-----------------------------------------");
                    Console.WriteLine("ID: " + empleado.id);
                    Console.WriteLine("Nombre: " + empleado.name);
                    Console.WriteLine("Direccion: " + empleado.address);
                    Console.WriteLine("Telefono: " + empleado.telephone);
                    Console.WriteLine("Nacionalidad: " + empleado.nationality);
                    Console.WriteLine("Sueldo: " + empleado.sueldo);
                    Console.WriteLine("-----------------------------------------");
                }
            }
            else
            {
                Console.WriteLine("No se crearon empleados");
            }
            if (listAdministrador.Count != 0)
            {
                Console.WriteLine("Lista de administrador creados: ");
                foreach (Administrador admin in listAdministrador)
                {
                    Console.WriteLine("-----------------------------------------");
                    Console.WriteLine("ID: " + admin.id);
                    Console.WriteLine("Nombre: " + admin.name);
                    Console.WriteLine("Direccion: " + admin.address);
                    Console.WriteLine("Telefono: " + admin.telephone);
                    Console.WriteLine("Nacionalidad: " + admin.nationality);
                    Console.WriteLine("Sueldo: " + admin.sueldo);
                    Console.WriteLine("-----------------------------------------");
                }
            }
            else
            {
                Console.WriteLine("No se crearon administradores");
            }
        }
    }
}
