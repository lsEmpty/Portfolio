﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Primerito
{
    public class Administrador : Persona
    {
        public Administrador() {
            this.sueldo = 9000000;
        }
        public double sueldo { get; set; }
    }
}
