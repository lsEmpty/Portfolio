﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Primerito
{
    public class Empleado : Persona
    {
        public Empleado() {
            this.sueldo = 3000000;
        }
        public double sueldo { get; set; }
    }
}
